# Gantungan Kunci

Deploy: upload ke GitHub, Import di vercel.com/new, klik Deploy.

Agar edit terlihat semua orang:
1. Buka situs, aktifkan Mode Edit, ubah teks dan foto.
2. Klik "Unduh content.json".
3. Taruh file itu di folder `public/` di GitHub (upload, commit).
4. Vercel otomatis deploy ulang (sekitar 1 menit). Semua pengunjung kini melihat hasil editmu.
