import { createElement, useEffect, useRef, useState } from "react";
import type { ChangeEvent, FocusEvent, ReactNode } from "react";

type Feature = { title: string; text: string };
type Spec = { label: string; value: string };
type Data = {
  name: string;
  tagline: string;
  description: string;
  price: string;
  features: Feature[];
  specs: Spec[];
  hero: string | null;
  gallery: string[];
  updatedAt?: number;
};

const KEY = "gantungan-kunci-v1";

const defaults: Data = {
  name: "Nama Gantungan Kunci",
  tagline: "Tulis satu kalimat singkat tentang produkmu di sini.",
  description:
    "Jelaskan produkmu: apa itu, dibuat dari apa, siapa yang cocok memakainya, dan masalah apa yang diselesaikan. Klik teks ini saat Mode Edit aktif untuk mengganti isinya.",
  price: "Rp 25.000",
  features: [
    { title: "Kuat dan tahan lama", text: "Jelaskan bahan dan ketahanannya." },
    { title: "Ringan dibawa", text: "Jelaskan ukuran dan bobotnya." },
    { title: "Bisa dipersonalisasi", text: "Jelaskan pilihan warna atau desain." },
  ],
  specs: [
    { label: "Bahan", value: "Akrilik" },
    { label: "Ukuran", value: "5 × 5 cm" },
    { label: "Berat", value: "12 gram" },
    { label: "Pilihan warna", value: "6 warna" },
  ],
  hero: null,
  gallery: [],
};

function load(): { data: Data; saved: boolean } {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { data: { ...defaults, ...JSON.parse(raw) }, saved: true };
  } catch {}
  return { data: defaults, saved: false };
}

function compress(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Gagal membaca file"));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("File bukan gambar"));
      img.onload = () => {
        const max = 1200;
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext("2d")!.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.82));
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  });
}

function Editable(props: {
  value: string;
  onSave: (v: string) => void;
  edit: boolean;
  as?: string;
  className?: string;
}) {
  const { value, onSave, edit, as = "span", className = "" } = props;
  return createElement(
    as,
    {
      className: className + (edit ? " editable" : ""),
      contentEditable: edit,
      suppressContentEditableWarning: true,
      onBlur: (e: FocusEvent<HTMLElement>) => onSave(e.currentTarget.innerText.trim()),
    },
    value
  );
}

function Reveal({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.classList.add("in");
          io.disconnect();
        }
      },
      { threshold: 0.15 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className="reveal">
      {children}
    </div>
  );
}

export default function App() {
  const initial = useRef(load());
  const [data, setData] = useState<Data>(initial.current.data);
  const [edit, setEdit] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(data));
      setError("");
    } catch {
      setError("Penyimpanan penuh. Hapus beberapa foto galeri agar perubahan tersimpan.");
    }
  }, [data]);

  const patch = (p: Partial<Data>) => setData((d) => ({ ...d, ...p, updatedAt: Date.now() }));

  useEffect(() => {
    fetch("/content.json", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((remote: Data | null) => {
        if (remote && typeof remote.name === "string" && (remote.updatedAt ?? 0) > (initial.current.data.updatedAt ?? 0)) {
          setData({ ...defaults, ...remote });
        }
      })
      .catch(() => {});
  }, []);

  function download() {
    const blob = new Blob([JSON.stringify({ ...data, updatedAt: data.updatedAt ?? Date.now() })], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "content.json";
    a.click();
    URL.revokeObjectURL(a.href);
  }

  async function pickHero(e: ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    try {
      patch({ hero: await compress(f) });
    } catch (err) {
      setError((err as Error).message);
    }
  }

  async function pickGallery(e: ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    e.target.value = "";
    try {
      const urls = await Promise.all(files.map(compress));
      setData((d) => ({ ...d, gallery: [...d.gallery, ...urls], updatedAt: Date.now() }));
    } catch (err) {
      setError((err as Error).message);
    }
  }

  const setFeature = (i: number, p: Partial<Feature>) =>
    patch({ features: data.features.map((f, j) => (j === i ? { ...f, ...p } : f)) });
  const setSpec = (i: number, p: Partial<Spec>) =>
    patch({ specs: data.specs.map((s, j) => (j === i ? { ...s, ...p } : s)) });

  function reset() {
    if (confirm("Hapus semua perubahan dan foto? Ini tidak bisa dibatalkan.")) {
      setData(defaults);
      setEdit(true);
    }
  }

  return (
    <>
      <header className="nav">
        <span className="logo">Gantung.</span>
        <nav>
          <a href="#fitur">Fitur</a>
          <a href="#detail">Detail</a>
          <a href="#galeri">Galeri</a>
        </nav>
      </header>

      <main>
        <section className="hero">
          <div className="hero-text">
            <Editable as="h1" value={data.name} edit={edit} onSave={(v) => patch({ name: v })} />
            <Editable as="p" className="tagline" value={data.tagline} edit={edit} onSave={(v) => patch({ tagline: v })} />
            <div className="price-row">
              <Editable className="price" value={data.price} edit={edit} onSave={(v) => patch({ price: v })} />
              <a className="btn" href="#detail">Lihat detail produk</a>
            </div>
          </div>

          <div className="hang">
            <svg className="ring" viewBox="0 0 120 120" aria-hidden="true">
              <circle cx="60" cy="60" r="44" fill="none" stroke="currentColor" strokeWidth="9" />
              <circle cx="60" cy="60" r="44" fill="none" stroke="#fff" strokeWidth="2" strokeDasharray="30 250" strokeLinecap="round" />
            </svg>
            <div className="chain" aria-hidden="true" />
            <label className={"photo" + (edit ? " clickable" : "")}>
              {data.hero ? (
                <img src={data.hero} alt={data.name} />
              ) : (
                <span className="empty">
                  <strong>Belum ada foto</strong>
                  {edit ? "Klik untuk unggah foto produk" : "Aktifkan Mode Edit untuk menambah foto"}
                </span>
              )}
              {edit && data.hero && <span className="swap">Ganti foto</span>}
              {edit && <input type="file" accept="image/*" onChange={pickHero} />}
            </label>
          </div>
        </section>

        <section className="about">
          <Reveal>
            <Editable as="p" className="lead" value={data.description} edit={edit} onSave={(v) => patch({ description: v })} />
          </Reveal>
        </section>

        <section id="fitur" className="features">
          <h2>Kenapa produk ini layak dipakai</h2>
          <ul>
            {data.features.map((f, i) => (
              <li key={i}>
                <Reveal>
                  <Editable as="h3" value={f.title} edit={edit} onSave={(v) => setFeature(i, { title: v })} />
                  <Editable as="p" value={f.text} edit={edit} onSave={(v) => setFeature(i, { text: v })} />
                </Reveal>
              </li>
            ))}
          </ul>
        </section>

        <section id="detail" className="specs">
          <h2>Spesifikasi</h2>
          <dl>
            {data.specs.map((s, i) => (
              <div key={i}>
                <Editable as="dt" value={s.label} edit={edit} onSave={(v) => setSpec(i, { label: v })} />
                <Editable as="dd" value={s.value} edit={edit} onSave={(v) => setSpec(i, { value: v })} />
              </div>
            ))}
          </dl>
        </section>

        <section id="galeri" className="gallery">
          <h2>Foto lainnya</h2>
          <div className="grid">
            {data.gallery.map((src, i) => (
              <figure key={i} style={{ animationDelay: `${i * 60}ms` }}>
                <img src={src} alt={`${data.name}, foto ${i + 1}`} />
                {edit && (
                  <button
                    className="remove"
                    aria-label={`Hapus foto ${i + 1}`}
                    onClick={() => patch({ gallery: data.gallery.filter((_, j) => j !== i) })}
                  >
                    Hapus
                  </button>
                )}
              </figure>
            ))}
            {edit && (
              <label className="add">
                Tambah foto
                <input type="file" accept="image/*" multiple onChange={pickGallery} />
              </label>
            )}
            {!edit && data.gallery.length === 0 && <p className="muted">Belum ada foto tambahan.</p>}
          </div>
        </section>
      </main>

      <footer>
        <span>{data.name}</span>
        <span>Tugas penjelasan produk</span>
      </footer>

      <div className="bar" role="toolbar" aria-label="Pengaturan halaman">
        {error && <span className="err">{error}</span>}
        {edit && <button className="ghost" onClick={reset}>Reset</button>}
        {edit && <button onClick={download}>Unduh content.json</button>}
        <button onClick={() => setEdit(!edit)}>{edit ? "Selesai edit" : "Mode Edit"}</button>
      </div>
    </>
  );
}
